﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Printer
    {

        public void Print(string value)
        {
            Console.WriteLine("{0}", value);
        }
    }
}
