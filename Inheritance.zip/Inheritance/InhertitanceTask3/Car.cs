﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InhertitanceTask3
{
    class Car : Vehicle
    {
        public Car(double price, double speed, DateTime year) : base (price, speed, year)
        {
                
        }
    }
}
